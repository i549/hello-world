import React from 'react';
import Button from '../../components/button';
import Message from '../../components/message';

export default function() {
    return (
        <div>
            demo/hello route
            <Button authority={"hello"}>提交</Button>
            <Message />
        </div>
    );
}
