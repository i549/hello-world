import React from 'react';
import Hello from './hello';

export default function() {
    return (
        <Hello />
    );
}
