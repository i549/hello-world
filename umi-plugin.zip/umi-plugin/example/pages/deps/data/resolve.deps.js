export default {
  "/button": {
    "deps": [
      "D:\\P00105\\code\\Library\\umi-plugin-auth\\example\\components\\AddButton.tsx",
      "D:\\P00105\\code\\Library\\umi-plugin-auth\\example\\components\\button.tsx"
    ],
    "auth": []
  },
  "/demo/hello": {
    "deps": [
      "D:\\P00105\\code\\Library\\umi-plugin-auth\\example\\components\\button.tsx",
      "D:\\P00105\\code\\Library\\umi-plugin-auth\\example\\components\\message.tsx"
    ],
    "auth": [
      "hello"
    ]
  },
  "/demo": {
    "deps": [
      "D:\\P00105\\code\\Library\\umi-plugin-auth\\example\\pages\\demo\\hello.tsx",
      "D:\\P00105\\code\\Library\\umi-plugin-auth\\example\\components\\button.tsx",
      "D:\\P00105\\code\\Library\\umi-plugin-auth\\example\\components\\message.tsx"
    ],
    "auth": [
      "hello"
    ]
  },
  "/deps": {
    "deps": [
      "D:\\P00105\\code\\Library\\umi-plugin-auth\\example\\pages\\deps\\data\\resolve.code.js",
      "D:\\P00105\\code\\Library\\umi-plugin-auth\\example\\pages\\deps\\data\\resolve.deps.js",
      "D:\\P00105\\code\\Library\\umi-plugin-auth\\example\\pages\\deps\\components\\DepsList.tsx",
      "D:\\P00105\\code\\Library\\umi-plugin-auth\\example\\pages\\deps\\components\\Toolbar.tsx"
    ],
    "auth": []
  },
  "/": {
    "deps": [
      "D:\\P00105\\code\\Library\\umi-plugin-auth\\example\\pages\\deps\\index.tsx",
      "D:\\P00105\\code\\Library\\umi-plugin-auth\\example\\pages\\deps\\data\\resolve.code.js",
      "D:\\P00105\\code\\Library\\umi-plugin-auth\\example\\pages\\deps\\data\\resolve.deps.js",
      "D:\\P00105\\code\\Library\\umi-plugin-auth\\example\\pages\\deps\\components\\DepsList.tsx",
      "D:\\P00105\\code\\Library\\umi-plugin-auth\\example\\pages\\deps\\components\\Toolbar.tsx"
    ],
    "auth": []
  }
}