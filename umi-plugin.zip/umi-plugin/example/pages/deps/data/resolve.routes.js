export default [
  {
    "path": "/button",
    "exact": true,
    "component": "./pages/button/index.tsx"
  },
  {
    "path": "/demo/hello",
    "exact": true,
    "component": "./pages/demo/hello.tsx"
  },
  {
    "path": "/demo",
    "exact": true,
    "component": "./pages/demo/index.tsx"
  },
  {
    "path": "/deps",
    "exact": true,
    "component": "./pages/deps/index.tsx"
  },
  {
    "path": "/",
    "exact": true,
    "component": "./pages/index.tsx"
  }
]