import React from 'react';
import {Row, Col, Form, Button} from 'antd';
import {RowProps} from "antd/lib/grid";
import {FormComponentProps, FormCreateOption} from "antd/lib/form";

import style from './style.less';

interface IProps extends FormComponentProps {
    fields: any[];
    rowProps: RowProps;
    onSearch: (values) => void;
    button?: 'search' | 'clear' | 'both' | 'none';
}

const searchBtn = () => (
    <Button type="primary" htmlType="submit">
        Search
    </Button>
);
const clearBtn = (form, submit) => (
    <Button
        style={{marginLeft: 8,}}
        onClick={() => {
            form.resetFields();
            submit();
        }}
    >
        Clear
    </Button>
);

class Toolbar extends React.PureComponent<IProps, any> {

    getFields = () => {
        const {form, fields, rowProps, button = 'both'} = this.props;

        const lastIdx = fields.length - 1;
        return fields.map((rowFields, index) => {
            return (
                <Row key={index} {...rowProps}>
                    {rowFields.map(field => {
                        if (React.isValidElement(field)) {
                            return field;
                        }
                        if (typeof field === 'function') {
                            return field(form, this.submit);
                        }
                        const {span, name, label, item, options} = field;
                        return (
                            <Col span={span} key={name}>
                                <Form.Item label={label}>{
                                    form.getFieldDecorator(name as string, options)(
                                        typeof item === 'function' ? item(field) : item
                                    )
                                }</Form.Item>
                            </Col>
                        )
                    })}
                    {
                        button === 'none' || lastIdx !== index ? null : (
                            <Col span={8} key="_buttons_">
                                <Form.Item>
                                    {['both', 'search'].includes(button) ? searchBtn() : null}
                                    {['both', 'clear'].includes(button) ? clearBtn(form, this.submit) : null}
                                </Form.Item>
                            </Col>
                        )
                    }
                </Row>
            )
        });
    };

    handleSearch = e => {
        e.preventDefault();
        this.submit();
    };

    submit = () => {
        this.props.form.validateFields((err, values) => {
            if (!err) {
                this.props.onSearch(values);
            }
        });
    };

    render() {
        return (
            <div>
                <Form className={style.searchForm} onSubmit={this.handleSearch}>{
                    this.getFields()
                }</Form>
            </div>
        )
    }
}

export const OriginalToolbar = Toolbar;

export const createToolbar = (options: FormCreateOption<any>) => (
    Form.create<IProps>(options)(Toolbar)
);

export default createToolbar({name: 'toolbar_search'});