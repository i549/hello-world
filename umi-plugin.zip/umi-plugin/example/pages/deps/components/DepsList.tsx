import _ from 'lodash';
import React, {useState} from "react";
import Toolbar from './Toolbar';
import {Card, Table, Input, Modal, message} from "antd";

import style from './style.less';

const fields = [
    [
        {
            span: 8,
            name: 'path',
            label: '路由',
            item: <Input placeholder="请输入路由" autoComplete={"off"}/>,
        }
    ]
];

const CodeModal = ({data, codes}) => {
    return (
        <div className={style.depsLinks}>{
            _.map(data, (link, idx) => {
                const code = codes[link].code;
                return (
                    <a key={idx} onClick={
                        () => Modal.info({
                            width: 1000,
                            title: (
                                <div>
                                    <span>解析源码</span>
                                    <a style={{float: 'right'}} onClick={() => {
                                        navigator.clipboard.writeText(code).then(() => {
                                            message.info(`copied`);
                                        })
                                    }}>copy</a>
                                </div>
                            ),
                            content: (
                                <Input.TextArea
                                    rows={30}
                                    value={code}
                                />
                            )
                        })
                    }>{link}</a>
                )
            })
        }</div>
    )
};

const getRender = (props) => {
    return data => {
        if (props.codes) {
            return (
                <CodeModal
                    data={data}
                    codes={props.codes}
                />
            )
        }
        return (
            <span style={{whiteSpace: 'pre'}}>{
                _.join(data, '\n')
            }</span>
        )
    }
};

export default (props) => {
    const [list, setList] = useState(props.list);
    const [page, setPage] = useState({
        current: 1,
        pageSize: 10,
        showSizeChanger: true,
        showTotal: total => `Total: ${total}`,
    });

    const onChange = (pagination, filters, sorter) => {
        setPage({...page, ...pagination});
    };
    const onSearch = values => {
        const {path} = values;
        if (path) {
            setList(_.filter(props.list, (data) => _.includes(_.lowerCase(data.path), _.lowerCase(path))));
        } else {
            setList(props.list);
        }
    };
    const codeRender = getRender(props);

    const columns = [
        {
            width: 80,
            title: '序号',
            dataIndex: 'sort',
        },
        {
            width: 400,
            title: '路由',
            dataIndex: 'path',
            render: data => {
                if (props.codes) {
                    return (
                        <CodeModal
                            data={[data]}
                            codes={props.codes}
                        />
                    )
                }
                return data;
            }
        },
        {
            width: 200,
            title: '名称',
            dataIndex: 'name',
        },
        {
            width: 400,
            title: '权限',
            dataIndex: 'auth',
            render: data => _.join(data, '\n'),
        },
        {
            title: '依赖',
            dataIndex: 'deps',
            render: data => {
                if (props.codes) {
                    return (
                        <CodeModal
                            data={data}
                            codes={props.codes}
                        />
                    )
                }
                return (
                    <span style={{whiteSpace: 'pre'}}>{
                        _.join(data, '\n')
                    }</span>
                )
            },
        },
    ];

    const {title} = props.info;
    return (
        <Card title={title ? `路由依赖列表 -> ${title}` : "路由依赖列表"}>
            <Toolbar
                fields={fields}
                rowProps={{gutter: 24}}
                onSearch={onSearch}
            />
            <Table
                bordered
                rowKey={"path"}
                columns={columns}
                dataSource={list}
                pagination={page}
                onChange={onChange}
                scroll={{y: 600}}
            />
        </Card>
    )
};