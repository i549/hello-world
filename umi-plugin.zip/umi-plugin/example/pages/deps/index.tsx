import _ from 'lodash';
import React from 'react';
import codes from './data/resolve.code';
import routeDeps from './data/resolve.deps';
import DepsList from './components/DepsList';

import 'antd/dist/antd.min.css';

const parseRoutes = (routeDeps) => {
    const
        routeInfo = {},
        routeKeys = [],
        routeList = [];

    let sort = 1;
    _.forEach(routeDeps, (dep, path) => {
        if(path !== '__info__') {
            routeKeys.push(path);
            routeList.push({path, sort: sort++, ...dep});
        } else {
            _.forEach(dep, (v, k) => routeInfo[k] = v);
        }
    });

    return {
        routeInfo,
        routeList,
        routeKeys,
    }
};

export default () => {
    const {routeList, routeInfo} = parseRoutes(routeDeps);

    return (
        <DepsList
            list={routeList}
            info={routeInfo}
            codes={codes}
        />
    )
}