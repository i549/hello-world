import React from 'react';
import AddButton from '../../components/AddButton';

/**
 * title: 按钮
 */
export default () => {
    const auth = 'SUBMIT';
    return (
        <AddButton auth={auth}/>
    )
};