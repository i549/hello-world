import React from 'react';
import Deps from './deps';

export default function () {
    return (
        <Deps/>
    );
}
