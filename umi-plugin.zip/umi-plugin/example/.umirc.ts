import {join, resolve} from 'path';
import {IConfig} from 'umi-types';
import {AuthPlugin} from '../src/typings';

export default {
    // treeShaking: true,
    alias: {
        '@': resolve(__dirname, '.'),
    },
    plugins: [
        ['umi-plugin-react', {
            routes: {
                exclude: [
                    /data\//,
                    /components\//,
                ],
            },
        }],
        [
            join(__dirname, '..', require('../package').main || 'index.js'),
            {
                showCode: true,
                // dir: join(__dirname, '../plt-deps'),
                dir: join(__dirname, './pages/deps/data'),
            } as AuthPlugin
        ],
    ],
} as IConfig;
