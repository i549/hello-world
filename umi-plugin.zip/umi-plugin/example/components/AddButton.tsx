import React from 'react';
import Button from './button';

export default (props) => {
    const {auth} = props;

    return (
        <Button authority={`ADD_${auth}`}>新增</Button>
    )
};