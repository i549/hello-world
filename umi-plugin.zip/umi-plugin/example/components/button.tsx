import React from 'react';

import style from './style.less';

interface IButtonProps {
    /** 标题 */
    title?: string;
    /** Tab下标 */
    tabIndex?: number;
    /** 权限标记 */
    authority?: string;

    [propName: string]: any;
}

class Button extends React.Component<IButtonProps> {
    render() {
        const {children, authority} = this.props;
        return (
            <button className={style.button}>
                {children}
                {authority}
            </button>
        )
    }
}

export default Button;