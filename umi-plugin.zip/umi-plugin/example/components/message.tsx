import React from 'react';

export const showMessage = () => {
    return <div>message</div>
};

export default () => {
    return (
        <div>
            <h2>Message</h2>
            <p>This is a demo message.</p>
        </div>
    )
};