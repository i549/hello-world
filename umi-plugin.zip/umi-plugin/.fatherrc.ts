export default [
    {
        cjs: 'babel',
        extraBabelPlugins: [
            "syntax-async-functions"
        ]
    },
];
