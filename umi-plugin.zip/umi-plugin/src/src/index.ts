export {default as authAnalyser} from './auth-analyser';
