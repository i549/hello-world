import {Node} from '@babel/core';
import traverse from '@babel/traverse';
import * as t from "@babel/types";
import {AnalyseOption} from '../typings';

/**
 * 处理AST（ES MODULE）
 * @param ast
 * @param opts
 */
export default (
    ast: Node,
    opts: AnalyseOption,
) => {
    const auth: string[] = [];
    const {authKey} = opts;

    if(!authKey) {
        return auth;
    }

    traverse(ast, {
        enter(path) {
            if(path.isIdentifier({name: authKey})) {
                if(t.isProperty(path.parent)) {
                    const pValue = path.parent.value;
                    if(t.isStringLiteral(pValue)) {
                        auth.push(pValue.value);
                    }
                }
            }
        }
    });

    return auth;
};