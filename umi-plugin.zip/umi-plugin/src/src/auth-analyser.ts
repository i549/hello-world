import {ParserOptions} from '@babel/core';
import * as parser from '@babel/parser';
import generator from '@babel/generator';
import {AnalyseOption} from '../typings';
import esAuthAnalyser from './es-auth-analyser';

const defaultParserOptions: ParserOptions = {
    sourceType: "module",
};

/**
 * 分析权限组件
 * @param content
 * @param options
 * @param parserOptions
 */
export default (
    content: string,
    options?: AnalyseOption,
    parserOptions?: ParserOptions,
) => {
    const ast = parser.parse(content, {
        ...defaultParserOptions, ...parserOptions,
    });

    const auth = esAuthAnalyser(ast, options);

    if(options.showCode) {
        const {code} = generator(ast, {}, content);
        return {
            content, code, auth,
        };
    } else {
        return {
            auth,
        };
    }
};