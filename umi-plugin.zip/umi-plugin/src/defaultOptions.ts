import {AuthPlugin} from "./typings";

export default {
    dir: 'plt-deps',
    fileName: 'deps',
    filePrefix: 'resolve',

    showCode: false,
    authKey: 'authority',
} as AuthPlugin;