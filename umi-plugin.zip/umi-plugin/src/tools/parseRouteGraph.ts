import _ from "lodash";

/**
 * 解析路由依赖中的权限数据
 * @param graph
 */
export default (graph) => {
    const routeGraph = {}, codes = {};
    const parseDeps = ({deps}) => {
        let authArr = [], depsArr = [];

        _.forEach(deps, (depGraph, key) => {
            const {auth, code, content} = depGraph;
            const childDeps = parseDeps(depGraph);

            codes[key] = {code, content};

            authArr = authArr
                .concat(auth)
                .concat(childDeps.authArr);

            depsArr = depsArr
                .concat([key])
                .concat(childDeps.depsArr);
        });

        return {authArr, depsArr};
    };

    if (graph) {
        _.forEach(graph, (value, key) => {
            const {auth, code, content} = value;
            const {authArr, depsArr} = parseDeps(value);
            codes[key] = {code, content};
            routeGraph[key] = {
                deps: _.uniq([].concat(depsArr)),
                auth: _.uniq([].concat(auth || []).concat(authArr)),
            };
        });
    }

    return {routeGraph, codes};
};