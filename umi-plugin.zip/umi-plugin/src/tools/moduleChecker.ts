import _ from 'lodash';
import {IModuleCheckOpts, PathMatch} from '../typings';
import {Minimatch} from 'minimatch';

const defaultOpts: IModuleCheckOpts = {
    includes: ['**/{pages,components}/**/*.{js,jsx,ts,tsx}'],
    excludes: ['.umi', '.umi-production', 'node_modules']
        .map(v => `**/${v}/**/*.*`),
};

const getMatchers = (pathMatch: PathMatch) => {
    const matches = Array.isArray(pathMatch) ? pathMatch : [pathMatch];
    return matches.map(p => (
        _.isRegExp(p) ? p : _.isString(p) ? new Minimatch(p) : {match: () => false}
    ));
};

/**
 * 模块匹配校验
 * @param options
 */
export default (
    options?: IModuleCheckOpts
) => {
    const {includes, excludes} = {...defaultOpts, ...options};
    const
        iMatchers = getMatchers(includes),
        eMatchers = getMatchers(excludes),
        makeWith = (res) => m => _.isRegExp(m) ? m.test(res) : m.match(res);

    return (module): boolean => {
        if (!module || !module.resource) {
            return false;
        }
        const {resource} = module;
        const make = makeWith(resource);

        return iMatchers.some(make) && !eMatchers.some(make);
    }
}