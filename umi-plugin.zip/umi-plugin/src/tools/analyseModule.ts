import _ from 'lodash';
import {ParserOptions} from "@babel/core";
import {authAnalyser} from '../ast';
import {AnalyseOption} from '../typings';

/**
 * 解析webpack module代码
 * @param module
 * @param options
 * @param parserOptions
 */
export default (
    module,
    options?: AnalyseOption,
    parserOptions?: ParserOptions,
) => {
    const source = _.get(module, '_source._value');

    if(typeof source === 'string') {
        return authAnalyser(source, options, parserOptions);
    }

    return {};
};