/**
 * 处理route字符串化数据
 * @param key
 * @param value
 */
export default (key, value) => {
    switch (key) {
        case 'component': {
            if (value.startsWith('() =>')) {
                return value;
            }
            const [component] = value.split('^^');
            return `require('${component}').default`;
        }
        case 'Routes':
            return `[${value
                .map(v => `require('${v}').default`)
                .join(', ')
                }]`;
        default:
            return value;
    }
};