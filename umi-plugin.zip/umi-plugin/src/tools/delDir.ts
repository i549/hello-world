import fs from 'fs';
import {join} from 'path';

const delDir = (path, skip?: boolean) => {
    if (path && fs.existsSync(path)) {
        const files = fs.readdirSync(path);
        files.forEach((file) => {
            const curPath = join(path, file);
            if (fs.statSync(curPath).isDirectory()) {
                delDir(curPath);
            } else {
                fs.unlinkSync(curPath);
            }
        });
        !skip && fs.rmdirSync(path);
    }
};

export default delDir;