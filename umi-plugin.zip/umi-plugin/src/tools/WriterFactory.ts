import fs from "fs";
import path from "path";
import delDir from "./delDir";
import {IWriteOptions} from "../typings";

const defaultOpts: IWriteOptions = {
    dir: '.',
    fileName: 'writer.log',
    showLog: (info: string, err?: boolean) => {
        if (err) {
            process.stdout.write(`ERROR: ${info}`);
        } else {
            process.stdout.write(info);
        }
    }
};

class Writer {
    options: IWriteOptions;

    constructor(opts: IWriteOptions) {
        this.options = {...defaultOpts, ...opts};
        this.mkDir();
    }

    private mkDir = () => {
        const {dir, clean} = this.options;
        if (!(fs.existsSync(dir)
            && fs.statSync(dir).isDirectory())) {
            fs.mkdirSync(dir);
        } else if (clean) {
            delDir(dir, true);
        }
    };

    private run = (name: string, func: Function) => {
        const {fileName, showLog, dir} = this.options;
        try {
            const file = path.join(dir, name || fileName);
            const basename = path.basename(file);

            const message = func(file);
            if (typeof message === 'string') {
                showLog(message.replace('${name}', basename));
            }
        } catch (err) {
            showLog(err, true);
        }
        return this;
    };

    write = (data: any, name?: string) => {
        return this.run(name, file => {
            fs.writeFileSync(file, data);
            return 'write ${name} file finish.';
        })
    };

    writeJs = (
        data: any,
        name?: string,
        replacer?: (key: string, value: any) => any,
        space?: string | number,
    ) => {
        return this.write(`export default ${
            JSON.stringify(data, replacer, space || 2)
        }`, name);
    };

    append = (data: any, name?: string) => {
        return this.run(name, file => {
            fs.appendFileSync(file, data);
            return 'append ${name} file finish.';
        })
    };

    appends = (datas: any[], name?: string, clean?: boolean) => {
        if (typeof name === 'boolean') {
            [clean, name] = [name, undefined];
        }
        if (clean) {
            this.write("", name);
        }
        return this.run(name, (file) => {
            datas.forEach(data => {
                fs.appendFileSync(file, data);
            });
            return 'appends ${name} file finish.';
        })
    };
}

class WriterFactory {
    static cache: { [propName: string]: Writer } = {};

    static clean = (id?: string) => {
        if (id) {
            delete WriterFactory.cache[id];
        } else {
            WriterFactory.cache = {};
        }
    };

    static getWriter = (options: IWriteOptions, id?: string) => {
        if (id) {
            const writer = new Writer(options);
            WriterFactory.cache[id] = writer;
            return writer;
        }
        return new Writer(options);
    };

    static write = (data: any, options: IWriteOptions) => {
        return WriterFactory.getWriter(options).write(data);
    };

    static writeJs = (data: any, options: IWriteOptions) => {
        return WriterFactory.getWriter(options).writeJs(data);
    };
}

export default WriterFactory;