import _ from "lodash";
import path from 'path';
import {IRouteDepsInfo} from '../typings';

/**
 * 转换路由数据
 * @param cwd
 * @param routes
 */
export default (cwd, routes) => {
    const pathMap = {}, componentMap = {}, info: IRouteDepsInfo = {};
    const getRoot = (routePath) => routePath.join('')
        .replace(/\/\//ig, '/');

    const toMap = (routes, routePath = []) => {
        _.forEach(routes, route => {
            const {component, routes, _title} = route;
            const _rootPath = routePath.concat(route.path);
            const root = getRoot(_rootPath);

            if (!info.title && _.isString(_title)) {
                info.title = _title;
            }

            if (_.isString(component) && !pathMap[root]) {
                const componentPath = path.join(cwd, component);
                pathMap[root] = componentPath;
                componentMap[componentPath] = root;
                if (Array.isArray(routes) && routes.length > 0) {
                    toMap(routes, _rootPath);
                }
            }
        });
    };

    toMap(routes);

    return {pathMap, componentMap, info};
}