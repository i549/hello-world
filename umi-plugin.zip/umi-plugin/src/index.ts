// ref:
// - https://umijs.org/plugin/develop.html
import {IApi} from 'umi-types';
import {AuthPlugin} from './typings';
import {name} from '../package.json';
import {isAbsolute, join} from 'path';
import defaultOptions from './defaultOptions';
import {WriterFactory, parseRouteGraph} from './tools';
import RouteDependenciesAnalyzerPlugin from './plugins/route-deps-plugin';

const stringify = (data) => JSON.stringify(data, null, 2);

const initPlugin = (api: IApi, options: AuthPlugin) => {
    const opts: AuthPlugin = {...defaultOptions, ...options};

    // write log
    process.stdout.write('\n');
    api.log.start(`${name} start`);
    api.log.info('options: ', stringify(options));
    api.log.info('merge options: ', stringify(opts));

    const getName = (name?: string) => {
        const prefix = opts.filePrefix ? `${opts.filePrefix}.` : "";
        return name ? `${prefix}${name}.js`
            : opts.fileName ? `${prefix}${opts.fileName}.js` : `${new Date().getTime()}.js`;
    };
    const showLog = (info, err) => err ? api.log.error(info) : api.log.success(info);
    const dir = isAbsolute(opts.dir) ? opts.dir : join(api.paths.cwd, opts.dir);

    const writer = WriterFactory.getWriter({
        dir,
        showLog,
        clean: true,
        fileName: getName(),
    });

    return {
        opts, writer, getName,
    }
};

export default function (api: IApi, options: AuthPlugin) {
    let app: any = {},
        isBuild = true,
        devStarted = false;

    const {forceBuild, devMode} = options || ({} as AuthPlugin);

    api.beforeDevServer(() => {
        if (!forceBuild) {
            isBuild = false;
        }
    });

    // 修改webpack配置，添加RouteDependenciesAnalyzerPlugin插件
    api.chainWebpackConfig(config => {
        if (devMode) {
            config.mode("development");
        }
        config.plugin('RouteDependenciesAnalyzerPlugin')
            .use(RouteDependenciesAnalyzerPlugin, [{
                cwd: api.paths.cwd,
                init: () => {
                    if (!isBuild) {
                        if (!devStarted) {
                            devStarted = true;
                            process.stdout.write('\n');
                            api.log.info(`${name} only start with build.\n`);
                        }
                        return false;
                    }
                    app = initPlugin(api, options);
                    return app.opts;
                },
                getRoutes: () => {
                    const {writer, getName} = app;
                    const routes = api.routes || api.getRoutes();
                    process.stdout.write('\n');
                    writer.writeJs(routes, getName('routes'));

                    return routes;
                },
                writer: (graph, info) => {
                    const {writer, getName, opts} = app;
                    const {routeGraph, codes} = parseRouteGraph(graph);

                    writer.writeJs(info, getName('info'));
                    writer.writeJs(graph, getName('graph'));
                    writer.writeJs(routeGraph);
                    if (opts.showCode) {
                        writer.writeJs(codes, getName('code'));
                    }
                },
            }])
            .end();
    });
}
