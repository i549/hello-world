import _ from 'lodash';
import {RouteDepsPlugin} from "../typings";
import {
    mapRoutes,
    moduleChecker,
    analyseModule,
    WriterFactory,
} from '../tools';

const DEF_FILE = 'route.deps.js';
const Tap = 'RouteDependenciesAnalyzerPlugin';

/**
 * 路由依赖关系分析插件（webpack）
 */
class RouteDependenciesAnalyzerPlugin {
    options: RouteDepsPlugin;

    constructor(options: RouteDepsPlugin) {
        this.options = {...options};
    }

    assignInfo = (info) => {
        return {
            ...info,
            ...this.options.info,
        }
    };

    assignOptions = (opts: RouteDepsPlugin) => {
        this.options = {...this.options, ...opts};
    };

    analyseRouteModules = (modules, routes) => {
        const {cwd, ...rest} = this.options;
        const
            graph = {},
            moduleDeps = {},
            check = moduleChecker(rest),
            {componentMap, info} = mapRoutes(cwd, routes);

        const getModuleDeps = (module, routeDeps, route) => {
            const {resource, dependencies} = module;
            if (moduleDeps[resource]) {
                return moduleDeps[resource];
            }

            const deps = {};
            if (dependencies) {
                _.forEach(dependencies, ({module}) => {
                    if (check(module)) {
                        const {resource} = module;
                        if (!routeDeps[resource]) {
                            routeDeps[resource] = true;
                            deps[resource] = getModuleDeps(module, routeDeps, route);
                        }
                    }
                })
            }

            return moduleDeps[resource] = {
                deps, ...analyseModule(module, rest),
            };
        };

        _.forEach(modules, module => {
            if (!check(module) || !componentMap[module.resource]) {
                return;
            }
            const routeDeps = {};
            graph[componentMap[module.resource]] = getModuleDeps(
                module, routeDeps, componentMap[module.resource]
            );
        });

        return {graph, info};
    };

    handleFinishModules = (modules, callback) => {
        const {init, getRoutes, cwd, file = DEF_FILE, writer} = this.options;
        if(_.isFunction(init)) {
            const opts = init();
            if(opts === false) {
                return callback && callback();
            }
            this.assignOptions(opts);
        }

        const routes = getRoutes();
        if(routes) {
            // 解析路由依赖关系
            const {graph, info} = this.analyseRouteModules(modules, routes);

            if (typeof writer === 'function') {
                writer.call(null, graph, this.assignInfo(info));
            } else {
                WriterFactory.writeJs(graph, {
                    dir: cwd,
                    fileName: file,
                });
            }
        }

        callback && callback();
    };

    apply(compiler) {
        // 打包完成即将输出时分析组件依赖
        compiler.hooks.emit.tapAsync(Tap, (compilation, callback) => {
            this.handleFinishModules(compilation.modules, callback);
        });
    }
}

export default RouteDependenciesAnalyzerPlugin;