/*路径匹配*/
import {IRoute} from "umi-types";

export type PathMatch = string | string[] | RegExp | RegExp[] | null;

export interface IModuleCheckOpts {
    /*包含的路径匹配*/
    includes?: PathMatch;
    /*不包含的路径匹配*/
    excludes?: PathMatch;
}

export interface IRouteDepsInfo {
    /*项目标题*/
    title?: string;
    /*项目描述*/
    description?: string;
}

export interface IWriteOptions {
    /*文件输出目录*/
    dir: string;
    /*文件输出名称*/
    fileName?: string;
    /*目录已存在是否先清空目录*/
    clean?: boolean;
    /*日志输出接口*/
    showLog?: (info: string | Error, err?: boolean) => void;
}

export interface IAuthPlugin {
    /*分析结果输出目录*/
    dir?: string;
    /*分析结果输出文件名*/
    fileName?: string;
    /*输出文件名统一前缀*/
    filePrefix?: string;
    /*指定项目信息*/
    info?: IRouteDepsInfo;
    /*是否使用开发模式打包*/
    devMode?: boolean;
    /*是否输出被分析代码，默认为false*/
    showCode?: boolean;
    /*强制编译：不区分是否运行umi build*/
    forceBuild?: boolean;
    /*权限key*/
    authKey?: string;
}

export interface IRouteDepsPlugin {
    /*编译项目目录*/
    cwd: string;
    /*获取路由接口*/
    getRoutes: () => IRoute[];
    /*结果输出文件*/
    file?: string;
    /*初始化插件，返回配置参数*/
    init: () => false | RouteDepsPlugin;
    /*结果输出接口，配置后file属性无效*/
    writer?: (graph: any, info: any) => void;
}

export type AuthPlugin = IModuleCheckOpts & IAuthPlugin;

export type RouteDepsPlugin = AuthPlugin & IRouteDepsPlugin;

export type AnalyseOption = AuthPlugin & {};
